package com.example.satmunia.triosolar;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.support.v7.app.ActionBar;

public class TriosolarActivity extends AppCompatActivity {
    WebView mywebview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.triosolar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.ic_launcher);

        //String ua = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31";
    //    String ua ="Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36";

        mywebview = (WebView) findViewById(R.id.webView);
//        String ua1=new WebView(this).getSettings().getUserAgentString();
//        mywebview.getSettings().setUserAgentString(ua);
//        WebSettings webSettings = mywebview.getSettings();
//        webSettings.setJavaScriptEnabled(true);

        mywebview.getSettings().setJavaScriptEnabled(true);
        mywebview.getSettings().setLoadWithOverviewMode(true);
        mywebview.getSettings().setUseWideViewPort(true);

        mywebview.getSettings().setSupportZoom(true);
        mywebview.getSettings().setBuiltInZoomControls(true);
        mywebview.getSettings().setDisplayZoomControls(false);

        mywebview.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        mywebview.setScrollbarFadingEnabled(false);


        mywebview.loadUrl("http://test.triosolar.co.in:8080/");
        mywebview.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
        if (mywebview.getParent() != null)
            ((ViewGroup) mywebview.getParent()).removeView(mywebview);
        setContentView(mywebview);
        //mywebview.getSettings().setDomStorageEnabled(true);

    }

  }
